﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Amin.Models
{
    // Lokacija: Models/EntitetA.cs
    public class EntitetA
    {
        public int Id { get; set; }

        // TODO: Dodaj svojstva za EntitetA (npr. Ime, Prezime, Email)
        public string Naziv { get; set; }
        public string Opis { get; set; }

        public override string ToString()
        {
            // TODO: Podesi kako da se entitet lepo ispiše u listi
            return Naziv;
        }
    }
}
