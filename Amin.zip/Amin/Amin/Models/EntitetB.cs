﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Amin.Models
{
    // Lokacija: Models/EntitetB.cs
    public class EntitetB
    {
        public int Id { get; set; }

        // TODO: Dodaj svojstva za EntitetB (npr. NazivStaze, DuzinaKM)
        public string NazivStaze { get; set; }
        public double Vrednost { get; set; }

        public override string ToString()
        {
            // TODO: Podesi kako da se entitet lepo ispiše u listi
            return NazivStaze;
        }
    }
}
