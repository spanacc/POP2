﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Amin.Models
{
    public class Veza
    {
        public int Id { get; set; }

        // --- Svojstva za čuvanje u CSV ---
        // TODO: Dodaj svojstva za samu vezu (npr. NazivTrke)
        public string NazivVeze { get; set; }

        // TODO: Veza ka EntitetuB (uvek ima samo jednog)
        public int EntitetBId { get; set; }

        // TODO: Veza ka EntitetuA (može biti jedan ili više)
        // Ako je veza 1-na-1 (jedan EntitetA po Vezi)
        // public int EntitetAId { get; set; }

        // Ako je veza 1-na-više (više EntitetaA po Vezi, kao trkači u trci)
        public List<int> EntitetiA_IDs { get; set; }

        // --- Pomoćna svojstva za rad u aplikaciji ---
        public EntitetB PovezaniEntitetB { get; set; }
        // public EntitetA PovezaniEntitetA { get; set; } // za 1-na-1
        public List<EntitetA> PovezaniEntitetiA { get; set; } // za 1-na-više

        // Konstruktor da se liste inicijalizuju
        public Veza()
        {
            // PovezaniEntitetiA = new List<EntitetA>();
            // EntitetiA_IDs = new List<int>();
        }
    }
}
