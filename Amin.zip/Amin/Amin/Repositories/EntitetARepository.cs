﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections.Generic;
using System.IO;
using Amin.Models; // TODO: Promeni "ImeProjekta"

namespace Amin.Repositories
{

    public class EntitetARepository
    {
        // TODO: Promeni putanju do fajla
        private readonly string _filePath = "Data/entiteti_a.csv";

        public EntitetARepository()
        {
            if (!Directory.Exists("Data")) Directory.CreateDirectory("Data");
            if (!File.Exists(_filePath)) File.Create(_filePath).Close();
        }

        public List<EntitetA> GetAll()
        {
            var lista = new List<EntitetA>();
            foreach (var linija in File.ReadAllLines(_filePath))
            {
                if (string.IsNullOrWhiteSpace(linija)) continue;
                var delovi = linija.Split(',');

                var entitet = new EntitetA
                {
                    Id = int.Parse(delovi[0]),
                    // TODO: Parsiraj ostala svojstva iz delova
                    Naziv = delovi[1],
                    Opis = delovi[2]
                };
                lista.Add(entitet);
            }
            return lista;
        }

        public void SaveAll(List<EntitetA> lista)
        {
            var linije = new List<string>();
            foreach (var entitet in lista)
            {
                // TODO: Formatiraj string za upis u CSV
                string linija = $"{entitet.Id},{entitet.Naziv},{entitet.Opis}";
                linije.Add(linija);
            }
            File.WriteAllLines(_filePath, linije);
        }
    }
}
