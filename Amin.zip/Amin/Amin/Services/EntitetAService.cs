﻿using Amin.Models;
using Amin.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Amin.Services
{
    public class EntitetAService
    {
        private readonly EntitetARepository _repository;

        public EntitetAService() { _repository = new EntitetARepository(); }
        public List<EntitetA> GetAll() { return _repository.GetAll(); }

        public void Add(EntitetA novi)
        {
            var lista = _repository.GetAll();
            novi.Id = lista.Count > 0 ? lista.Max(e => e.Id) + 1 : 1;
            lista.Add(novi);
            _repository.SaveAll(lista);
        }

        public void Delete(int id)
        {
            var lista = _repository.GetAll();
            var zaBrisanje = lista.FirstOrDefault(e => e.Id == id);
            if (zaBrisanje != null)
            {
                lista.Remove(zaBrisanje);
                _repository.SaveAll(lista);
            }
        }
    }
}
