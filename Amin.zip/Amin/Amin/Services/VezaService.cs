﻿using Amin.Models;
using Amin.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Amin.Services
{
    public class VezaService
    {
        private readonly VezaRepository _vezaRepo; // napraviti isto kao entitetA.repositoriy
        private readonly EntitetARepository _entitetARepo;
        private readonly EntitetBRepository _entitetBRepo;// napraviti isto kao entitetA.repositoriy

        public VezaService()
        {
            _vezaRepo = new VezaRepository(); // napraviti isto kao entitetA.repositoriy
            _entitetARepo = new EntitetARepository();
            _entitetBRepo = new EntitetBRepository();// napraviti isto kao entitetA.repositoriy
        }

        // GLAVNA LOGIKA SPAJANJA
        public List<Veza> GetAll()
        {
            var veze = _vezaRepo.GetAll();
            var sviA = _entitetARepo.GetAll();
            var sviB = _entitetBRepo.GetAll();

            foreach (var veza in veze)
            {
                // TODO: Spoji EntitetB
                veza.PovezaniEntitetB = sviB.FirstOrDefault(b => b.Id == veza.EntitetBId);

                // TODO: Spoji EntitetA (ili više njih)
                // veza.PovezaniEntitetA = sviA.FirstOrDefault(a => a.Id == veza.EntitetAId); // za 1-na-1

                // Za 1-na-više
                // veza.PovezaniEntitetiA = sviA.Where(a => veza.EntitetiA_IDs.Contains(a.Id)).ToList();
            }
            return veze;
        }

        // Add i Delete su slični kao gore...
    }
}
