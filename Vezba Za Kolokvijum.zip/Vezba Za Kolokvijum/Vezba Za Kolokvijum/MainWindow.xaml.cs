﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Vezba_Za_Kolokvijum.Models;
using Vezba_Za_Kolokvijum.Services;
using Vezba_Za_Kolokvijum.Windows;

namespace Vezba_Za_Kolokvijum
{
    public partial class MainWindow : Window
    {
        // Kreiramo instance naših servisa. Oni su "mozak" koji ćemo koristiti.
        private readonly ZaduzenjeService _zaduzenjeService;
        private readonly ClanService _clanService;
        private readonly KnjigaService _knjigaService;

        public MainWindow()
        {
            InitializeComponent();

            // Inicijalizujemo servise
            _zaduzenjeService = new ZaduzenjeService();
            _clanService = new ClanService();
            _knjigaService = new KnjigaService();

            // Odmah po pokretanju, učitaj i prikaži podatke
            OsveziPrikaz();
        }

        private void OsveziPrikaz()
        {
            // Pozivamo naš "pametni" servis da nam da sva zaduženja sa popunjenim podacima
            List<Zaduzenje> svaZaduzenja = _zaduzenjeService.GetAll();

            // DataGrid ne može direktno da prikaže npr. `zaduzenje.Clan.Ime`.
            // Zato pravimo novu, privremenu listu objekata koji imaju "ravne" propertije.
            // Ovi propertiji se zovu isto kao `Binding` u XAML-u.
            var prikazZaduzenja = svaZaduzenja.Select(z => new
            {
                Id = z.Id, // Čuvamo ID da bismo znali šta da obrišemo
                ImePrezimeClana = z.Clan != null ? $"{z.Clan.Ime} {z.Clan.Prezime}" : "NEPOZNAT ČLAN",
                NaslovKnjige = z.Knjiga != null ? z.Knjiga.Naslov : "NEPOZNATA KNJIGA",
                DatumZaduzenja = z.DatumZaduzenja.ToString("dd.MM.yyyy")
            }).ToList();

            // Postavljamo tu listu kao izvor podataka za našu tabelu
            ZaduzenjaDataGrid.ItemsSource = prikazZaduzenja;
        }

        // Metode koje će se pozvati kada se klikne na dugmiće
        // Za sada će biti prazne, implementiraćemo ih jednu po jednu

        private void DodajKnjigu_Click(object sender, RoutedEventArgs e)
        {
            // Kreiramo instancu našeg novog prozora
            DodajKnjiguWindow dodajKnjiguProzor = new DodajKnjiguWindow();

            // ShowDialog() otvara prozor i čeka da se on zatvori pre nego što nastavi sa izvršavanjem koda.
            // To je važno jer ne želimo da osvežimo prikaz pre nego što je knjiga zaista dodata.
            dodajKnjiguProzor.ShowDialog();

            // Nakon što se prozor za dodavanje zatvori, osveži prikaz u glavnoj tabeli.
            // Ovo je važno da bi se nova knjiga odmah videla (ako bismo je prikazivali negde).
            // Iako je ne prikazujemo direktno, ovo je dobra praksa.
            OsveziPrikaz();
        }

        private void DodajClana_Click(object sender, RoutedEventArgs e)
        {
            // (Ne zaboravi da na vrhu fajla mora postojati 'using BibliotekaAplikacija.Windows;')
            DodajClanaWindow dodajClanaProzor = new DodajClanaWindow();
            dodajClanaProzor.ShowDialog();

            // Nema potrebe za OsveziPrikaz() jer tabela prikazuje samo zaduženja
        }

        // U MainWindow.xaml.cs

        private void NovoZaduzenje_Click(object sender, RoutedEventArgs e)
        {
            // (Opet, proveri da li postoji 'using BibliotekaAplikacija.Windows;' na vrhu)
            NovoZaduzenjeWindow novoZaduzenjeProzor = new NovoZaduzenjeWindow();
            novoZaduzenjeProzor.ShowDialog();

            // E, SADA JE OVO KLJUČNO!
            // Nakon što se prozor za dodavanje zaduženja zatvori, moramo osvežiti
            // prikaz u glavnoj tabeli da bi se novo zaduženje odmah videlo.
            OsveziPrikaz();
        }

        private void ObrisiZaduzenje_Click(object sender, RoutedEventArgs e)
        {
            // Proveravamo da li je korisnik selektovao nešto u tabeli
            if (ZaduzenjaDataGrid.SelectedItem == null)
            {
                MessageBox.Show("Molimo vas, prvo selektujte zaduženje koje želite da obrišete.", "Greška", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            // Pitamo korisnika za potvrdu
            MessageBoxResult rezultat = MessageBox.Show("Da li ste sigurni da želite da obrišete selektovano zaduženje?", "Potvrda brisanja", MessageBoxButton.YesNo, MessageBoxImage.Question);

            if (rezultat == MessageBoxResult.Yes)
            {
                // Uzimamo selektovani objekat. On je anonimnog tipa koji smo napravili u OsveziPrikaz.
                // Moramo da pročitamo njegov 'Id' property.
                var selektovanoZaduzenje = (dynamic)ZaduzenjaDataGrid.SelectedItem;
                int idZaBrisanje = selektovanoZaduzenje.Id;

                // Pozivamo servis da obriše zaduženje sa tim ID-jem
                _zaduzenjeService.Delete(idZaBrisanje);

                // Osvežavamo prikaz da se promena vidi
                OsveziPrikaz();
            }
        }
    }
}