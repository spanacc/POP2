﻿namespace Vezba_Za_Kolokvijum.Models
{
    public class Clan
    {
        public int Id { get; set; }
        public string Ime { get; set; }
        public string Prezime { get; set; }
        public string BrojClanskeKarte { get; set; }
        public override string ToString()
        {
            return $"{Ime} {Prezime} ({BrojClanskeKarte})";
        }
    }
}