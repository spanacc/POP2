﻿namespace Vezba_Za_Kolokvijum.Models
{
    public class Knjiga
    {
        public int Id { get; set; }
        public string Naslov { get; set; }
        public string Autor { get; set; }
        public override string ToString()
        {
            return $"{Naslov} - {Autor}";
        }
    }
}