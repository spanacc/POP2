﻿using System;

namespace Vezba_Za_Kolokvijum.Models
{
    public class Zaduzenje
    {
        public int Id { get; set; }
        public int ClanId { get; set; }
        public int KnjigaId { get; set; }
        public DateTime DatumZaduzenja { get; set; }

        // Pomoćna polja
        public Clan Clan { get; set; }
        public Knjiga Knjiga { get; set; }
    }
}