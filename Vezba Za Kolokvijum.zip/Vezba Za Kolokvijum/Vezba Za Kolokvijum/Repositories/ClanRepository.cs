﻿using Vezba_Za_Kolokvijum.Models;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Vezba_Za_Kolokvijum.Models;

namespace Vezba_Za_Kolokvijum.Repositories
{
    public class ClanRepository
    {
        private readonly string _filePath = "Data/clanovi.csv";

        public ClanRepository()
        {
            if (!Directory.Exists("Data")) Directory.CreateDirectory("Data");
            if (!File.Exists(_filePath)) File.Create(_filePath).Close();
        }

        public List<Clan> GetAll()
        {
            List<Clan> clanovi = new List<Clan>();
            string[] linije = File.ReadAllLines(_filePath);

            foreach (string linija in linije)
            {
                if (string.IsNullOrWhiteSpace(linija)) continue;
                string[] delovi = linija.Split(',');
                Clan clan = new Clan
                {
                    Id = int.Parse(delovi[0]),
                    Ime = delovi[1],
                    Prezime = delovi[2],
                    BrojClanskeKarte = delovi[3]
                };
                clanovi.Add(clan);
            }
            return clanovi;
        }

        public void SaveAll(List<Clan> clanovi)
        {
            List<string> linije = new List<string>();
            foreach (Clan clan in clanovi)
            {
                string linija = $"{clan.Id},{clan.Ime},{clan.Prezime},{clan.BrojClanskeKarte}";
                linije.Add(linija);
            }
            File.WriteAllLines(_filePath, linije);
        }
    }
}