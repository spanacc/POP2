﻿
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Vezba_Za_Kolokvijum.Models;

namespace Vezba_Za_Kolokvijum.Repositories
{
    public class KnjigaRepository
    {
        private readonly string _filePath = "Data/knjige.csv";

        public KnjigaRepository()
        {
            if (!Directory.Exists("Data")) Directory.CreateDirectory("Data");
            if (!File.Exists(_filePath)) File.Create(_filePath).Close();
        }

        public List<Knjiga> GetAll()
        {
            List<Knjiga> knjige = new List<Knjiga>();
            string[] linije = File.ReadAllLines(_filePath);

            foreach (string linija in linije)
            {
                if (string.IsNullOrWhiteSpace(linija)) continue;
                string[] delovi = linija.Split(',');
                Knjiga knjiga = new Knjiga
                {
                    Id = int.Parse(delovi[0]),
                    Naslov = delovi[1],
                    Autor = delovi[2]
                };
                knjige.Add(knjiga);
            }
            return knjige;
        }

        public void SaveAll(List<Knjiga> knjige)
        {
            List<string> linije = new List<string>();
            foreach (Knjiga knjiga in knjige)
            {
                string linija = $"{knjiga.Id},{knjiga.Naslov},{knjiga.Autor}";
                linije.Add(linija);
            }
            File.WriteAllLines(_filePath, linije);
        }
    }
}