﻿
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using Vezba_Za_Kolokvijum.Models;

namespace Vezba_Za_Kolokvijum.Repositories
{
    public class ZaduzenjeRepository
    {
        private readonly string _filePath = "Data/zaduzenja.csv";

        public ZaduzenjeRepository()
        {
            if (!Directory.Exists("Data")) Directory.CreateDirectory("Data");
            if (!File.Exists(_filePath)) File.Create(_filePath).Close();
        }

        public List<Zaduzenje> GetAll()
        {
            List<Zaduzenje> zaduzenja = new List<Zaduzenje>();
            string[] linije = File.ReadAllLines(_filePath);

            foreach (string linija in linije)
            {
                if (string.IsNullOrWhiteSpace(linija)) continue;
                string[] delovi = linija.Split(',');
                Zaduzenje z = new Zaduzenje
                {
                    Id = int.Parse(delovi[0]),
                    ClanId = int.Parse(delovi[1]),
                    KnjigaId = int.Parse(delovi[2]),
                    DatumZaduzenja = DateTime.Parse(delovi[3], CultureInfo.InvariantCulture)
                };
                zaduzenja.Add(z);
            }
            return zaduzenja;
        }

        public void SaveAll(List<Zaduzenje> zaduzenja)
        {
            List<string> linije = new List<string>();
            foreach (Zaduzenje z in zaduzenja)
            {
                string linija = $"{z.Id},{z.ClanId},{z.KnjigaId},{z.DatumZaduzenja.ToString("O", CultureInfo.InvariantCulture)}";
                linije.Add(linija);
            }
            File.WriteAllLines(_filePath, linije);
        }
    }
}