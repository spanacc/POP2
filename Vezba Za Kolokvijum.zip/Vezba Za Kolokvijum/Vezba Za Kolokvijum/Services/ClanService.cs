﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Vezba_Za_Kolokvijum.Models;
using Vezba_Za_Kolokvijum.Repositories;

namespace Vezba_Za_Kolokvijum.Services
{
    public class ClanService
    {
        private readonly ClanRepository _clanRepository;
        public ClanService()
        {
            _clanRepository = new ClanRepository();
        }

        public List<Clan> GetAll()
        {
            return _clanRepository.GetAll();
        }

        public void Add(Clan noviClan)
        {
            List<Clan> sviClanovi = _clanRepository.GetAll();
            int noviId = sviClanovi.Count > 0 ? sviClanovi.Max(c => c.Id) + 1 : 1;
            noviClan.Id = noviId;
            sviClanovi.Add(noviClan);
            _clanRepository.SaveAll(sviClanovi);
        }

        public void Delete(int idClana)
        {
            List<Clan> sviClanovi = _clanRepository.GetAll();
            Clan clanZaBrisanje = sviClanovi.FirstOrDefault(c => c.Id == idClana);
            if (clanZaBrisanje != null)
            {
                sviClanovi.Remove(clanZaBrisanje);
                _clanRepository.SaveAll(sviClanovi);
            }
        }
    }
}