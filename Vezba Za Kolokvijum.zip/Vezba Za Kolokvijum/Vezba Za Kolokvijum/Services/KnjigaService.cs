﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Vezba_Za_Kolokvijum.Models;
using Vezba_Za_Kolokvijum.Repositories;

namespace Vezba_Za_Kolokvijum.Services
{
    public class KnjigaService
    {
        private readonly KnjigaRepository _knjigaRepository;
        public KnjigaService()
        {
            _knjigaRepository = new KnjigaRepository();
        }

        public List<Knjiga> GetAll()
        {
            return _knjigaRepository.GetAll();
        }

        public void Add(Knjiga novaKnjiga)
        {
            List<Knjiga> sveKnjige = _knjigaRepository.GetAll();
            int noviId = sveKnjige.Count > 0 ? sveKnjige.Max(k => k.Id) + 1 : 1;
            novaKnjiga.Id = noviId;
            sveKnjige.Add(novaKnjiga);
            _knjigaRepository.SaveAll(sveKnjige);
        }

        public void Delete(int idKnjige)
        {
            List<Knjiga> sveKnjige = _knjigaRepository.GetAll();
            Knjiga knjigaZaBrisanje = sveKnjige.FirstOrDefault(k => k.Id == idKnjige);
            if (knjigaZaBrisanje != null)
            {
                sveKnjige.Remove(knjigaZaBrisanje);
                _knjigaRepository.SaveAll(sveKnjige);
            }
        }
    }
}