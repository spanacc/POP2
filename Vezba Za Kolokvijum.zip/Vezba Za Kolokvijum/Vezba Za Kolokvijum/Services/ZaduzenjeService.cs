﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Vezba_Za_Kolokvijum.Models;
using Vezba_Za_Kolokvijum.Repositories;
using System.Linq;

namespace Vezba_Za_Kolokvijum.Services
{
    public class ZaduzenjeService
    {
        private readonly ZaduzenjeRepository _zaduzenjeRepository;
        private readonly ClanRepository _clanRepository;
        private readonly KnjigaRepository _knjigaRepository;

        public ZaduzenjeService()
        {
            _zaduzenjeRepository = new ZaduzenjeRepository();
            _clanRepository = new ClanRepository();
            _knjigaRepository = new KnjigaRepository();
        }

        public List<Zaduzenje> GetAll()
        {
            List<Zaduzenje> zaduzenja = _zaduzenjeRepository.GetAll();
            List<Clan> sviClanovi = _clanRepository.GetAll();
            List<Knjiga> sveKnjige = _knjigaRepository.GetAll();

            foreach (Zaduzenje z in zaduzenja)
            {
                z.Clan = sviClanovi.FirstOrDefault(c => c.Id == z.Clan igaId);
            }
            return zaduzenja;
        }

        public void Add(Zaduzenje novoZaduzenje)
        {
            List<Zaduzenje> svaZaduzenja = _zaduzenjeRepository.GetAll();
            int noviId = svaZaduzenja.Count > 0 ? svaZaduzenja.Max(z => z.Id) + 1 : 1;
            novoZaduzenje.Id = noviId;
            svaZaduzenja.Add(novoZaduzenje);
            _zaduzenjeRepository.SaveAll(svaZaduzenja);
        }

        public void Delete(int idZaduzenja)
        {
            List<Zaduzenje> svaZaduzenja = _zaduzenjeRepository.GetAll();
            Zaduzenje zaBrisanje = svaZaduzenja.FirstOrDefault(z => z.Id == idZaduzenja);
            if (zaBrisanje != null)
            {
                svaZaduzenja.Remove(zaBrisanje);
                _zaduzenjeRepository.SaveAll(svaZaduzenja);
            }
        }
    }
}
