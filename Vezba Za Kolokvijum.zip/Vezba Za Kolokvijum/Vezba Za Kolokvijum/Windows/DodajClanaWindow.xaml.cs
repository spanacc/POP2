﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Vezba_Za_Kolokvijum.Models;
using Vezba_Za_Kolokvijum.Services;

namespace Vezba_Za_Kolokvijum.Windows
{
    public partial class DodajClanaWindow : Window
    {
        // Treba nam ClanService da sačuvamo novog člana
        private readonly ClanService _clanService;

        public DodajClanaWindow()
        {
            InitializeComponent();
            _clanService = new ClanService();
        }

        private void SacuvajButton_Click(object sender, RoutedEventArgs e)
        {
            // Validacija
            if (string.IsNullOrWhiteSpace(ImeTextBox.Text) ||
                string.IsNullOrWhiteSpace(PrezimeTextBox.Text) ||
                string.IsNullOrWhiteSpace(BrojKarteTextBox.Text))
            {
                MessageBox.Show("Molimo vas, popunite sva polja.", "Greška", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            // Kreiranje novog objekta
            Clan noviClan = new Clan
            {
                Ime = ImeTextBox.Text,
                Prezime = PrezimeTextBox.Text,
                BrojClanskeKarte = BrojKarteTextBox.Text
            };

            // Poziv servisa
            _clanService.Add(noviClan);

            // Obaveštenje i zatvaranje
            MessageBox.Show("Član je uspešno dodat!", "Uspeh", MessageBoxButton.OK, MessageBoxImage.Information);
            this.Close();
        }
    }
}
