﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Vezba_Za_Kolokvijum.Models;
using Vezba_Za_Kolokvijum.Services;

namespace Vezba_Za_Kolokvijum.Windows
{
    public partial class DodajKnjiguWindow : Window
    {
        // Treba nam KnjigaService da bismo mogli da sačuvamo novu knjigu.
        private readonly KnjigaService _knjigaService;

        public DodajKnjiguWindow()
        {
            InitializeComponent();
            _knjigaService = new KnjigaService();
        }

        private void SacuvajButton_Click(object sender, RoutedEventArgs e)
        {
            // 1. Validacija: Proveri da li je korisnik uneo oba polja.
            if (string.IsNullOrWhiteSpace(NaslovTextBox.Text) || string.IsNullOrWhiteSpace(AutorTextBox.Text))
            {
                MessageBox.Show("Molimo vas, popunite sva polja.", "Greška", MessageBoxButton.OK, MessageBoxImage.Warning);
                return; // Prekini dalje izvršavanje ako je greška
            }

            // 2. Kreiraj novi Knjiga objekat na osnovu unosa
            Knjiga novaKnjiga = new Knjiga
            {
                Naslov = NaslovTextBox.Text,
                Autor = AutorTextBox.Text
                // ID ne postavljamo mi, to radi servis!
            };

            // 3. Pozovi servis da sačuva novu knjigu
            _knjigaService.Add(novaKnjiga);

            // 4. Obavesti korisnika i zatvori prozor
            MessageBox.Show("Knjiga je uspešno dodata!", "Uspeh", MessageBoxButton.OK, MessageBoxImage.Information);
            this.Close(); // Ovo zatvara trenutni (DodajKnjiguWindow) prozor
        }
    }
}
