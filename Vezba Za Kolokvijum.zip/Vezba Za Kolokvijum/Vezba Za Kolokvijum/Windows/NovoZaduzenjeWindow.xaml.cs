﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Vezba_Za_Kolokvijum.Models;
using Vezba_Za_Kolokvijum.Services;

namespace Vezba_Za_Kolokvijum.Windows
{
    public partial class NovoZaduzenjeWindow : Window
    {
        // Trebaju nam SVI servisi!
        private readonly ClanService _clanService;
        private readonly KnjigaService _knjigaService;
        private readonly ZaduzenjeService _zaduzenjeService;

        public NovoZaduzenjeWindow()
        {
            InitializeComponent();

            _clanService = new ClanService();
            _knjigaService = new KnjigaService();
            _zaduzenjeService = new ZaduzenjeService();

            // Pozivamo metodu koja će popuniti naše padajuće liste
            UcitajPodatkeZaComboBox();
        }

        private void UcitajPodatkeZaComboBox()
        {
            // Učitaj sve članove i postavi ih kao izvor za prvi ComboBox
            ClanComboBox.ItemsSource = _clanService.GetAll();

            // Učitaj sve knjige i postavi ih kao izvor za drugi ComboBox
            KnjigaComboBox.ItemsSource = _knjigaService.GetAll();

            // Postavi današnji datum kao podrazumevani
            DatumDatePicker.SelectedDate = DateTime.Now;
        }

        private void SacuvajButton_Click(object sender, RoutedEventArgs e)
        {
            // 1. Validacija: Proveri da li je korisnik izabrao vrednosti iz listi
            if (ClanComboBox.SelectedItem == null ||
                KnjigaComboBox.SelectedItem == null ||
                DatumDatePicker.SelectedDate == null)
            {
                MessageBox.Show("Molimo vas, izaberite člana, knjigu i datum.", "Greška", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            // 2. Preuzmi selektovane OBJEKTE iz ComboBox-ova
            Clan selektovaniClan = (Clan)ClanComboBox.SelectedItem;
            Knjiga selektovanaKnjiga = (Knjiga)KnjigaComboBox.SelectedItem;
            DateTime selektovaniDatum = (DateTime)DatumDatePicker.SelectedDate;

            // 3. Kreiraj novi Zaduzenje objekat
            Zaduzenje novoZaduzenje = new Zaduzenje
            {
                // Popunjavamo samo ID-jeve, jer se oni čuvaju u CSV-u!
                ClanId = selektovaniClan.Id,
                KnjigaId = selektovanaKnjiga.Id,
                DatumZaduzenja = selektovaniDatum
            };

            // 4. Pozovi servis da sačuva novo zaduženje
            _zaduzenjeService.Add(novoZaduzenje);

            // 5. Obavesti korisnika i zatvori prozor
            MessageBox.Show("Zaduženje je uspešno kreirano!", "Uspeh", MessageBoxButton.OK, MessageBoxImage.Information);
            this.Close();
        }
    }
}