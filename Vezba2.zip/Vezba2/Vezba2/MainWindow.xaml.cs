﻿using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using Vezba2.Service;
using Vezba2.Models;
using Vezba2.Repositories;
using Vezba2.WIndows;

namespace Vezba2
{
    public partial class MainWindow : Window
    {
        // POTREBAN NAM JE SAMO JEDAN SERVIS!
        private readonly ReceptService _receptService;

        public MainWindow()
        {
            InitializeComponent();

            // Kreiramo instancu SAMO ReceptService-a.
            _receptService = new ReceptService();

            OsveziListuRecepata();
        }

        private void OsveziListuRecepata()
        {
            var prethodnoSelektovan = ReceptiListBox.SelectedItem as Recept;
            var recepti = _receptService.GetAll();
            ReceptiListBox.ItemsSource = recepti;
            if (prethodnoSelektovan != null)
            {
                var noviItem = recepti.FirstOrDefault(r => r.Id == prethodnoSelektovan.Id);
                if (noviItem != null)
                {
                    ReceptiListBox.SelectedItem = noviItem;
                }
            }
        }

        private void ReceptiListBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (ReceptiListBox.SelectedItems.Count == 1 && ReceptiListBox.SelectedItem is Recept selektovaniRecept)
            {
                DetaljiPanel.DataContext = selektovaniRecept;
                NazivReceptaTextBlock.Text = selektovaniRecept.Naziv;
                UputstvoTextBlock.Text = selektovaniRecept.Uputstvo;
                DetaljiPanel.Visibility = Visibility.Visible;
            }
            else
            {
                DetaljiPanel.Visibility = Visibility.Collapsed;
            }
        }

        private void DodajRecept_Click(object sender, RoutedEventArgs e)
        {
            AddReceptWindow prozor = new AddReceptWindow();
            prozor.ShowDialog();
            OsveziListuRecepata();
        }

        // OVA METODA NE KORISTI SERVIS IZ MAINWINDOW-A
        private void DodajSastojak_Click(object sender, RoutedEventArgs e)
        {
            // Prozor za dodavanje sastojaka će imati svoju, internu logiku.
            // MainWindow ne mora da zna kako on radi.
            AddSastojakWindow prozor = new AddSastojakWindow();
            prozor.ShowDialog();
        }

        private void ObrisiRecept_Click(object sender, RoutedEventArgs e)
        {
            if (ReceptiListBox.SelectedItem is Recept selektovaniRecept)
            {
                MessageBoxResult rezultat = MessageBox.Show(
                    $"Da li ste sigurni da želite da obrišete recept '{selektovaniRecept.Naziv}'?",
                    "Potvrda brisanja", MessageBoxButton.YesNo, MessageBoxImage.Warning);

                if (rezultat == MessageBoxResult.Yes)
                {
                    // Koristimo jedini servis koji imamo.
                    _receptService.Delete(selektovaniRecept.Id);
                    OsveziListuRecepata();
                }
            }
            else
            {
                MessageBox.Show("Molimo vas, prvo selektujte recept koji želite da obrišete.", "Obaveštenje");
            }
        }

        private void GenerisiListu_Click(object sender, RoutedEventArgs e)
        {
            var selektovaniRecepti = ReceptiListBox.SelectedItems.Cast<Recept>().ToList();
            if (selektovaniRecepti.Count > 0)
            {
                ShoppingListWindow prozor = new ShoppingListWindow(selektovaniRecepti);
                prozor.ShowDialog();
            }
            else
            {
                MessageBox.Show("Molimo vas, selektujte barem jedan recept da biste generisali listu za kupovinu.", "Obaveštenje");
            }
        }
    }
}