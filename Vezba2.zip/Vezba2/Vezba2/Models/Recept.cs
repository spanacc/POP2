﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Vezba2.Models
{
    public class Recept
    {

        public int Id { get; set; }
        public string Naziv {  get; set; }
        public string Uputstvo { get; set; }

        public List<ReceptSastojak> Sastojci { get; set; }
        public Recept()
        {
            Sastojci = new List<ReceptSastojak>();
        }
        public override string ToString()
        {
            return Naziv;
        }
    }
}
