﻿using System;
using System.Collections.Generic;
using System.DirectoryServices.ActiveDirectory;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Vezba2.Models
{
    public class ReceptSastojak
    {
       public int ReceptId { get; set; }
       public int SastojakId {  get; set; }
        public double Kolicina {  get; set; }
        public string MernaJedinica {  get; set; }
        public Sastojak Sastojak { get; set; }

        public string PrikazListe => $"{Sastojak?.Naziv}-{Kolicina}-{MernaJedinica}";
    }
}
