﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Vezba2.Models;

namespace Vezba2.Repositories
{
    public class ReceptRepository
    {
        private readonly string _filePath = "Data/recept.csv";


        public ReceptRepository()
        {

            if (!Directory.Exists("Data"))
            {
                Directory.CreateDirectory("Data");
            }

            if (!File.Exists(_filePath))
            {
                File.Create(_filePath);
            }
        }
        public List<Recept> GetAll()
        {
            List<Recept> recepti = new List<Recept>();
            string[] linije = File.ReadAllLines(_filePath);
            foreach (string linija in linije)
            {
                if (string.IsNullOrWhiteSpace(linija)) continue;
                string[] delovi = linija.Split(",");
                Recept recept = new Recept
                {
                    Id = int.Parse(delovi[0]),
                    Naziv = delovi[1],
                    Uputstvo = delovi[2]
                };
                recepti.Add(recept);
            }
            return recepti;
        }
        public void SaveAll(List<Recept> recepti)
        {
            List<string> linije = new List<string>();
            foreach (Recept recept in recepti)
            {
                string linija = $"{recept.Id}|{recept.Naziv}|{recept.Uputstvo}";
            }
            File.WriteAllLines(_filePath, linije);
        }

    }

}
