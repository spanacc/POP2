﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Vezba2.Models;



namespace Vezba2.Repositories
{
    public class ReceptSastojakRepository
    {
        private readonly string _filePath = "Data/receptsastojak.csv";


        public ReceptSastojakRepository()
        {

            if (!Directory.Exists("Data"))
            {
                Directory.CreateDirectory("Data");
            }

            if (!File.Exists(_filePath))
            {
                File.Create(_filePath);
            }
        }
        public List<ReceptSastojak> GetAll()
        {
            List<ReceptSastojak> receptsastojci = new List<ReceptSastojak>();
            string[] linije = File.ReadAllLines(_filePath);
            foreach (string linija in linije)
            {
                if (string.IsNullOrWhiteSpace(linija)) continue;
                string[] delovi = linija.Split(",");
                ReceptSastojak receptsastojak = new ReceptSastojak
                {
                    ReceptId=int.Parse(delovi[0]),
                    SastojakId=int.Parse(delovi[1]),
                    Kolicina=int.Parse(delovi[2]),
                    MernaJedinica = delovi[3]
                };
                receptsastojci.Add(receptsastojak);
            }
            return receptsastojci;
        }
        public void SaveAll(List<ReceptSastojak> receptsastojci)
        {
            List<string> linije = new List<string>();
            foreach (ReceptSastojak receptsastojak in receptsastojci)
            {
                string linija = $"{receptsastojak.ReceptId},{receptsastojak.SastojakId},{receptsastojak.Kolicina},{receptsastojak.MernaJedinica}";
            }
            File.WriteAllLines(_filePath, linije);
        }

    }

}
