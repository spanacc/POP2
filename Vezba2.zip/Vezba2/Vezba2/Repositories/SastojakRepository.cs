﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection.PortableExecutable;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using Vezba2.Models;
using static System.Net.WebRequestMethods;
using File = System.IO.File;

namespace Vezba2.Models.Repositories
{
    public class SastojakRepository
    {
        private readonly string _filePath = "Data/sastojci.csv";

        public SastojakRepository()
        {
            if (!Directory.Exists("Data"))
            {
                Directory.CreateDirectory("Data");
            }
            if (!File.Exists(_filePath))
            {
                File.Create(_filePath).Close();
            }
        }

        /// <summary>
        /// Čita sve sastojke iz CSV fajla na siguran način.
        /// </summary>
        public List<Sastojak> GetAll()
        {
            List<Sastojak> sastojci = new List<Sastojak>();

            // Proveravamo da li fajl uopšte postoji pre čitanja
            if (!File.Exists(_filePath))
            {
                return sastojci; // Vrati praznu listu ako fajla nema
            }

            string[] linije = File.ReadAllLines(_filePath);

            foreach (string linija in linije)
            {
                // Preskačemo prazne ili neispravne redove
                if (string.IsNullOrWhiteSpace(linija))
                {
                    continue;
                }

                string[] delovi = linija.Split(',');

                // NAJVAŽNIJA PROVERA:
                // Da li red ima tačno 2 dela (ID i Naziv)?
                // Ovo sprečava pucanje programa ako je red oštećen.
                if (delovi.Length == 2)
                {
                    // Koristimo TryParse da budemo još sigurniji
                    if (int.TryParse(delovi[0], out int id))
                    {
                        Sastojak sastojak = new Sastojak
                        {
                            Id = id,
                            Naziv = delovi[1]
                        };
                        sastojci.Add(sastojak);
                    }
                }
            }
            return sastojci;
        }

        /// <summary>
        /// Upisuje listu sastojaka u CSV, gazeći stari sadržaj.
        /// </summary>
        public void SaveAll(List<Sastojak> sastojci)
        {
            List<string> linije = new List<string>();
            foreach (var sastojak in sastojci)
            {
                string linija = $"{sastojak.Id},{sastojak.Naziv}";
                linije.Add(linija);
            }
            File.WriteAllLines(_filePath, linije);
        }
    }
}
