﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Vezba2.Models;
using Vezba2.Models.Repositories;
using Vezba2.Repositories;
namespace Vezba2.Service
{
    public class ReceptService
    {
        private readonly ReceptRepository _receptRepo;
        private readonly SastojakRepository _sastojakRepo;
        private readonly ReceptSastojakRepository _vezaRepo;

        public ReceptService()
        {
            _receptRepo = new ReceptRepository();
            _sastojakRepo = new SastojakRepository();
            _vezaRepo = new ReceptSastojakRepository();
        }

        public List<Recept> GetAll()
        {
            var recepti = _receptRepo.GetAll();
            var sastojci = _sastojakRepo.GetAll();
            var veze = _vezaRepo.GetAll();

            foreach (var recept in recepti)
            {
                var relevantneVeze = veze.Where(v => v.ReceptId == recept.Id).ToList();
                foreach (var veza in relevantneVeze)
                {
                    veza.Sastojak = sastojci.FirstOrDefault(s => s.Id == veza.SastojakId);
                    recept.Sastojci.Add(veza);
                }
            }
            return recepti;
        }

        public void Add(Recept noviRecept)
        {
            var sviRecepti = _receptRepo.GetAll();
            noviRecept.Id = sviRecepti.Count > 0 ? sviRecepti.Max(r => r.Id) + 1 : 1;
            sviRecepti.Add(noviRecept);
            _receptRepo.SaveAll(sviRecepti);

            var sveVeze = _vezaRepo.GetAll();
            foreach (var veza in noviRecept.Sastojci)
            {
                veza.ReceptId = noviRecept.Id;
                sveVeze.Add(veza);
            }
            _vezaRepo.SaveAll(sveVeze);
        }

        public void Delete(int receptId)
        {
            var sviRecepti = _receptRepo.GetAll();
            sviRecepti.RemoveAll(r => r.Id == receptId);
            _receptRepo.SaveAll(sviRecepti);

            var sveVeze = _vezaRepo.GetAll();
            sveVeze.RemoveAll(v => v.ReceptId == receptId);
            _vezaRepo.SaveAll(sveVeze);
        }
    }
}
