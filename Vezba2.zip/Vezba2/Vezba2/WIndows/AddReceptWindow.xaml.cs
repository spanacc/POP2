﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Vezba2.Models;
using Vezba2.Models.Repositories;
using Vezba2.Service;

namespace Vezba2.WIndows
{
    public partial class AddReceptWindow : Window
    {
        // Repozitorijum za dobijanje liste sastojaka
        private readonly SastojakRepository _sastojakRepository;
        // Servis za čuvanje kompletnog recepta
        private readonly ReceptService _receptService;

        private List<ReceptSastojak> _sastojciZaNoviRecept;

        public AddReceptWindow()
        {
            InitializeComponent();
            _sastojakRepository = new SastojakRepository();
            _receptService = new ReceptService();
            _sastojciZaNoviRecept = new List<ReceptSastojak>();

            // Popuni ComboBox direktno iz repozitorijuma
            SastojakComboBox.ItemsSource = _sastojakRepository.GetAll();
        }

        // Ova metoda ostaje ista
        private void DodajSastojakURecept_Click(object sender, RoutedEventArgs e)
        {
            if (SastojakComboBox.SelectedItem == null ||
                string.IsNullOrWhiteSpace(KolicinaTextBox.Text) ||
                string.IsNullOrWhiteSpace(MernaJedinicaTextBox.Text) ||
                !double.TryParse(KolicinaTextBox.Text, out double kolicina))
            {
                MessageBox.Show("Molimo popunite sva polja ispravno.", "Greška");
                return;
            }

            var selektovaniSastojak = (Sastojak)SastojakComboBox.SelectedItem;
            var noviReceptSastojak = new ReceptSastojak
            {
                SastojakId = selektovaniSastojak.Id,
                Sastojak = selektovaniSastojak,
                Kolicina = kolicina,
                MernaJedinica = MernaJedinicaTextBox.Text
            };
            _sastojciZaNoviRecept.Add(noviReceptSastojak);

            SastojciListView.ItemsSource = null;
            SastojciListView.ItemsSource = _sastojciZaNoviRecept;

            SastojakComboBox.SelectedIndex = -1;
            KolicinaTextBox.Clear();
            MernaJedinicaTextBox.Clear();
        }

        // Ova metoda koristi ReceptService i ostaje ista
        private void SacuvajRecept_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(NazivTextBox.Text) || string.IsNullOrWhiteSpace(UputstvoTextBox.Text))
            {
                MessageBox.Show("Molimo unesite naziv i uputstvo za recept.", "Greška");
                return;
            }
            if (_sastojciZaNoviRecept.Count == 0)
            {
                MessageBox.Show("Recept mora imati barem jedan sastojak.", "Greška");
                return;
            }

            Recept noviRecept = new Recept
            {
                Naziv = NazivTextBox.Text,
                Uputstvo = UputstvoTextBox.Text,
                Sastojci = _sastojciZaNoviRecept
            };

            // Koristimo ReceptService jer on zna kako da sačuva i recept i njegove veze
            _receptService.Add(noviRecept);

            MessageBox.Show("Recept je uspešno sačuvan!", "Uspeh");
            this.Close();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            // Učitaj svežu listu sastojaka iz fajla i postavi je kao izvor za ComboBox
            SastojakComboBox.ItemsSource = _sastojakRepository.GetAll();
        }
    }
}
