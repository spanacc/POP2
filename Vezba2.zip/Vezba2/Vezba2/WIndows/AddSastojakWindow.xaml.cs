﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Vezba2.Models;
using Vezba2.Models.Repositories;

namespace Vezba2.WIndows
{
    public partial class AddSastojakWindow : Window
    {
        // Ne treba nam servis, koristimo repozitorijum direktno
        private readonly SastojakRepository _sastojakRepository;

        public AddSastojakWindow()
        {
            InitializeComponent();
            _sastojakRepository = new SastojakRepository();
        }

        private void SacuvajButton_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(NazivTextBox.Text))
            {
                MessageBox.Show("Molimo vas, unesite naziv sastojka.", "Greška", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            // Logika koja je pre bila u servisu, sada je ovde
            var sviSastojci = _sastojakRepository.GetAll();

            // Provera da li sastojak već postoji
            if (sviSastojci.Any(s => s.Naziv.ToLower() == NazivTextBox.Text.ToLower()))
            {
                MessageBox.Show("Sastojak sa ovim imenom već postoji.", "Greška");
                return;
            }

            // Kreiranje novog sastojka
            var noviSastojak = new Sastojak
            {
                Id = sviSastojci.Count > 0 ? sviSastojci.Max(s => s.Id) + 1 : 1,
                Naziv = NazivTextBox.Text
            };

            sviSastojci.Add(noviSastojak);
            _sastojakRepository.SaveAll(sviSastojci);

            MessageBox.Show("Sastojak je uspešno sačuvan!", "Uspeh", MessageBoxButton.OK, MessageBoxImage.Information);
            this.Close();
        }
    }
}