﻿using WpfCrudTemplate.Models;
using WpfCrudTemplate.Services;
using WpfCrudTemplate.Windows; // Važno: using za folder sa pomoćnim prozorima
using System.Windows;
using System.Windows.Controls;
namespace WpfCrudTemplate
{
    public partial class MainWindow : Window
    {
        private readonly GlavniEntitetService _glavniService = new GlavniEntitetService();

        public MainWindow()
        {
            InitializeComponent();
            RefreshGlavnaLista(); // Odmah po pokretanju, popuni listu
        }

        // Metoda za osvežavanje podataka u glavnoj listi
        private void RefreshGlavnaLista()
        {
            GlavnaLista.ItemsSource = _glavniService.GetAll();
        }

        // Događaj koji se okida kada korisnik klikne na stavku u listi
        private void GlavnaLista_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            // Proveravamo da li je nešto selektovano
            if (GlavnaLista.SelectedItem is GlavniEntitet selektovani)
            {
                // Popunjavamo kontrole na desnoj strani podacima iz selektovanog objekta
                NazivDetalji.Text = selektovani.Naziv;
                OpisDetalji.Text = selektovani.Opis;
                VezeListView.ItemsSource = selektovani.Veze; // Prikazujemo listu njegovih veza
                DetaljiPanel.Visibility = Visibility.Visible; // Prikazujemo panel
            }
            else
            {
                // Ako ništa nije selektovano, sakrivamo panel
                DetaljiPanel.Visibility = Visibility.Collapsed;
            }
        }

        // Otvara prozor za dodavanje novog sporednog entiteta
        private void AddSporedni_Click(object sender, RoutedEventArgs e)
        {
            var prozor = new AddSporedniWindow();
            prozor.ShowDialog();
            // Nema potrebe za osvežavanjem glavnog prozora ovde
        }

        // Otvara prozor za dodavanje novog glavnog entiteta
        private void AddGlavni_Click(object sender, RoutedEventArgs e)
        {
            var prozor = new AddEditGlavniWindow();
            prozor.ShowDialog();
            // Nakon što se prozor zatvori, obavezno osveži listu!
            RefreshGlavnaLista();
        }

        // Briše selektovani glavni entitet
        private void DeleteGlavni_Click(object sender, RoutedEventArgs e)
        {
            if (GlavnaLista.SelectedItem is GlavniEntitet selektovani)
            {
                if (MessageBox.Show("Da li ste sigurni da želite da obrišete '" + selektovani.Naziv + "'?", "Potvrda brisanja", MessageBoxButton.YesNo) == MessageBoxResult.Yes)
                {
                    _glavniService.Delete(selektovani.Id);
                    RefreshGlavnaLista(); // Osveži listu da se obrisana stavka ukloni
                }
            }
            else
            {
                MessageBox.Show("Molimo vas, selektujte stavku koju želite da obrišete.");
            }
        }
    }
}