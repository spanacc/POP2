﻿// TODO: Preimenuj fajl i klasu u nešto smisleno, npr. Recept.cs
using System.Collections.Generic; // Potrebno zbog List<T>

namespace WpfCrudTemplate.Models
{
    public class GlavniEntitet
    {
        // Jedinstveni identifikator. Svaki red u CSV-u mora imati svoj ID.
        public int Id { get; set; }

        // TODO: Dodaj svojstva koja opisuju glavni entitet, npr. NazivRecepta, Uputstvo
        public string Naziv { get; set; }
        public string Opis { get; set; }

        // Ovo je ključno za povezivanje. Svaki GlavniEntitet će u sebi sadržati listu
        // svojih veza ka SporednimEntitetima. Ovu listu će popuniti servis.
        public List<Veza> Veze { get; set; }

        // Konstruktor. UVEK je dobra praksa da se liste inicijalizuju odmah
        // pri kreiranju objekta, da bi se izbegla greška "Object reference not set to an instance of an object".
        public GlavniEntitet()
        {
            Veze = new List<Veza>();
        }

        // Metoda koja određuje kako će se objekat prikazati kao tekst.
        // Koristi se npr. u ListBox-u ako postavimo DisplayMemberPath.
        public override string ToString()
        {
            return Naziv;
        }
    }
}