﻿// TODO: Preimenuj fajl i klasu, npr. Sastojak.cs
namespace WpfCrudTemplate.Models
{
    public class SporedniEntitet
    {
        // Jedinstveni ID sporednog entiteta.
        public int Id { get; set; }

        // TODO: Dodaj svojstva koja opisuju sporedni entitet, npr. NazivSastojka
        public string Naziv { get; set; }

        // Ovo je NAJVAŽNIJA metoda za ovaj model, jer omogućava da ComboBox
        // automatski prikaže Naziv umesto "WpfCrudTemplate.Models.SporedniEntitet".
        public override string ToString()
        {
            return Naziv;
        }
    }
}