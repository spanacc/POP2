﻿// Ovo je model koji predstavlja vezu u CSV-u (npr. recept_sastojak.csv)
namespace WpfCrudTemplate.Models
{
    public class Veza
    {
        // === SVOJSTVA KOJA SE ČUVAJU U CSV-u ===

        // ID Glavnog entiteta na koji se ova veza odnosi.
        public int GlavniEntitetId { get; set; }

        // ID Sporednog entiteta na koji se ova veza odnosi.
        public int SporedniEntitetId { get; set; }

        // TODO: Dodaj svojstva koja opisuju samu vezu, ne entitete.
        // Primeri: Kolicina, MernaJedinica, Vreme, Cena...
        public double Kolicina { get; set; }
        public string MernaJedinica { get; set; }

        // === POMOĆNA SVOJSTVA (ne čuvaju se u CSV-u) ===

        // Ovde ćemo smestiti ceo objekat SporednogEntiteta.
        // Servis će ovo popuniti da bismo lakše prikazali npr. Naziv sastojka.
        public SporedniEntitet SporedniEntitet { get; set; }

        // Ovo svojstvo služi samo za lep prikaz u ListView-u na UI.
        // Automatski formatira string na osnovu popunjenih podataka.
        public string PrikazZaListu
        {
            get
            {
                // Proveravamo da li je servis popunio SporedniEntitet pre nego što pokušamo da mu pristupimo.
                if (SporedniEntitet != null)
                {
                    // TODO: Prilagodi ovaj ispis da odgovara tvojim svojstvima.
                    return SporedniEntitet.Naziv + " - " + Kolicina + " " + MernaJedinica;
                }
                return "Greška pri učitavanju veze.";
            }
        }
    }
}