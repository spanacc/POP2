﻿using WpfCrudTemplate.Models;
using System.Collections.Generic;
using System.IO;
namespace WpfCrudTemplate.Repositories
{
    public class GlavniEntitetRepository
    {
        private readonly string _filePath = "Data/glavni.csv"; // TODO: Promeni ime fajla
        public GlavniEntitetRepository() { if (!Directory.Exists("Data")) Directory.CreateDirectory("Data"); if (!File.Exists(_filePath)) File.Create(_filePath).Close(); }
        public List<GlavniEntitet> GetAll()
        {
            var lista = new List<GlavniEntitet>();
            foreach (var linija in File.ReadAllLines(_filePath))
            {
                if (string.IsNullOrWhiteSpace(linija)) continue;
                var delovi = linija.Split('|'); // Koristimo '|' da bi Opis mogao da sadrži zareze
                if (delovi.Length == 3 && int.TryParse(delovi[0], out int id))
                    lista.Add(new GlavniEntitet { Id = id, Naziv = delovi[1], Opis = delovi[2] });
            }
            return lista;
        }
        public void SaveAll(List<GlavniEntitet> lista)
        {
            var linije = new List<string>();
            foreach (var entitet in lista)
                // Uklanjamo '|' iz opisa da ne bismo pokvarili format fajla
                linije.Add(string.Join("|", entitet.Id, entitet.Naziv, entitet.Opis.Replace("|", "")));
            File.WriteAllLines(_filePath, linije);
        }
    }
}