﻿using WpfCrudTemplate.Models;
using System.Collections.Generic;
using System.IO;
namespace WpfCrudTemplate.Repositories
{
    public class SporedniEntitetRepository
    {
        private readonly string _filePath = "Data/sporedni.csv"; // TODO: Promeni ime fajla
        public SporedniEntitetRepository() { if (!Directory.Exists("Data")) Directory.CreateDirectory("Data"); if (!File.Exists(_filePath)) File.Create(_filePath).Close(); }
        public List<SporedniEntitet> GetAll()
        {
            var lista = new List<SporedniEntitet>();
            foreach (var linija in File.ReadAllLines(_filePath))
            {
                if (string.IsNullOrWhiteSpace(linija)) continue;
                var delovi = linija.Split(',');
                if (delovi.Length == 2 && int.TryParse(delovi[0], out int id))
                    lista.Add(new SporedniEntitet { Id = id, Naziv = delovi[1] });
            }
            return lista;
        }
        public void SaveAll(List<SporedniEntitet> lista)
        {
            var linije = new List<string>();
            foreach (var entitet in lista)
                linije.Add(string.Join(",", entitet.Id, entitet.Naziv));
            File.WriteAllLines(_filePath, linije);
        }
    }
}