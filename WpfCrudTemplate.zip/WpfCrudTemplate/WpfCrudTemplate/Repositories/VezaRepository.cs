﻿using WpfCrudTemplate.Models;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
namespace WpfCrudTemplate.Repositories
{
    public class VezaRepository
    {
        private readonly string _filePath = "Data/veze.csv"; // TODO: Promeni ime fajla
        public VezaRepository() { if (!Directory.Exists("Data")) Directory.CreateDirectory("Data"); if (!File.Exists(_filePath)) File.Create(_filePath).Close(); }
        public List<Veza> GetAll()
        {
            var lista = new List<Veza>();
            foreach (var linija in File.ReadAllLines(_filePath))
            {
                if (string.IsNullOrWhiteSpace(linija)) continue;
                var delovi = linija.Split(',');
                if (delovi.Length == 4 && int.TryParse(delovi[0], out int gId) && int.TryParse(delovi[1], out int sId) && double.TryParse(delovi[2], CultureInfo.InvariantCulture, out double kol))
                    lista.Add(new Veza { GlavniEntitetId = gId, SporedniEntitetId = sId, Kolicina = kol, MernaJedinica = delovi[3] });
            }
            return lista;
        }
        public void SaveAll(List<Veza> lista)
        {
            var linije = new List<string>();
            foreach (var veza in lista)
                linije.Add(string.Join(",", veza.GlavniEntitetId, veza.SporedniEntitetId, veza.Kolicina.ToString(CultureInfo.InvariantCulture), veza.MernaJedinica));
            File.WriteAllLines(_filePath, linije);
        }
    }
}