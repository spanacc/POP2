﻿using WpfCrudTemplate.Models;
using WpfCrudTemplate.Repositories;
using System.Collections.Generic;
using System.Linq; // Potrebno za .Where(), .FirstOrDefault(), .Max()
namespace WpfCrudTemplate.Services
{
    public class GlavniEntitetService
    {
        // Servis poznaje sve repozitorijume koji su mu potrebni da sklopi kompletnu informaciju.
        private readonly GlavniEntitetRepository _glavniRepo = new GlavniEntitetRepository();
        private readonly SporedniEntitetRepository _sporedniRepo = new SporedniEntitetRepository();
        private readonly VezaRepository _vezaRepo = new VezaRepository();

        /// <summary>
        /// Vraća listu SVIH glavnih entiteta, sa popunjenim listama njihovih veza.
        /// Ovo je najvažnija metoda u servisu.
        /// </summary>
        public List<GlavniEntitet> GetAll()
        {
            // 1. Učitaj "sirove" podatke iz svih fajlova
            var glavniEntiteti = _glavniRepo.GetAll();
            var sporedniEntiteti = _sporedniRepo.GetAll();
            var sveVeze = _vezaRepo.GetAll();

            // 2. Prođi kroz svaki GlavniEntitet
            foreach (var glavni in glavniEntiteti)
            {
                // 3. Pronađi samo one veze koje se odnose na TRENUTNI GlavniEntitet
                var relevantneVeze = sveVeze.Where(v => v.GlavniEntitetId == glavni.Id).ToList();

                // 4. Prođi kroz pronađene veze i obogati ih podacima
                foreach (var veza in relevantneVeze)
                {
                    // U pomoćno svojstvo 'SporedniEntitet' u Vezi, upiši ceo objekat
                    // Sporednog entiteta (npr. ceo Sastojak objekat, ne samo ID).
                    veza.SporedniEntitet = sporedniEntiteti.FirstOrDefault(s => s.Id == veza.SporedniEntitetId);
                }

                // 5. Dodeli kompletiranu listu veza Glavnom entitetu.
                glavni.Veze = relevantneVeze;
            }
            return glavniEntiteti;
        }

        /// <summary>
        /// Dodaje novi glavni entitet i sve njegove veze u odgovarajuće CSV fajlove.
        /// </summary>
        public void Add(GlavniEntitet novi)
        {
            // --- Logika za čuvanje Glavnog entiteta ---
            var sviGlavni = _glavniRepo.GetAll();
            // Odredi novi ID
            novi.Id = sviGlavni.Count > 0 ? sviGlavni.Max(g => g.Id) + 1 : 1;
            sviGlavni.Add(novi);
            _glavniRepo.SaveAll(sviGlavni); // Sačuvaj u glavni.csv

            // --- Logika za čuvanje Veza ---
            var sveVeze = _vezaRepo.GetAll();
            foreach (var veza in novi.Veze)
            {
                // Postavi ID upravo kreiranog glavnog entiteta na svaku vezu
                veza.GlavniEntitetId = novi.Id;
                sveVeze.Add(veza);
            }
            _vezaRepo.SaveAll(sveVeze); // Sačuvaj u veze.csv
        }

        /// <summary>
        /// Briše glavni entitet i sve veze povezane sa njim.
        /// </summary>
        public void Delete(int id)
        {
            // Obriši entitet iz glavni.csv
            var sviGlavni = _glavniRepo.GetAll();
            sviGlavni.RemoveAll(g => g.Id == id);
            _glavniRepo.SaveAll(sviGlavni);

            // Obriši sve njegove veze iz veze.csv
            var sveVeze = _vezaRepo.GetAll();
            sveVeze.RemoveAll(v => v.GlavniEntitetId == id);
            _vezaRepo.SaveAll(sveVeze);
        }
    }
}