﻿using WpfCrudTemplate.Models;
using WpfCrudTemplate.Repositories;
using System.Collections.Generic;
using System.Linq;
namespace WpfCrudTemplate.Services
{
    public class SporedniEntitetService
    {
        private readonly SporedniEntitetRepository _repository = new SporedniEntitetRepository();

        // Vraća sve sporedne entitete (npr. za popunjavanje ComboBox-a)
        public List<SporedniEntitet> GetAll() { return _repository.GetAll(); }

        // Logika za dodavanje novog sporednog entiteta
        public void Add(SporedniEntitet novi)
        {
            var svi = _repository.GetAll();
            novi.Id = svi.Count > 0 ? svi.Max(s => s.Id) + 1 : 1;
            svi.Add(novi);
            _repository.SaveAll(svi);
        }
    }
}