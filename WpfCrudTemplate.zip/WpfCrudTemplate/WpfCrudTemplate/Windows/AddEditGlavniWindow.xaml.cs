﻿using WpfCrudTemplate.Models;
using WpfCrudTemplate.Services;
using System.Collections.Generic;
using System.Windows;
namespace WpfCrudTemplate.Windows
{
    public partial class AddEditGlavniWindow : Window
    {
        private readonly GlavniEntitetService _glavniService = new GlavniEntitetService();
        private readonly SporedniEntitetService _sporedniService = new SporedniEntitetService();

        // Ovo je privremena lista u koju skupljamo veze PRE nego što sačuvamo ceo glavni entitet.
        private List<Veza> _privremeneVeze = new List<Veza>();

        public AddEditGlavniWindow() { InitializeComponent(); }

        // Događaj koji se okida svaki put kada se prozor otvori.
        // Koristimo ga da popunimo ComboBox svežim podacima.
        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            SporedniComboBox.ItemsSource = _sporedniService.GetAll();
        }

        // Dodaje jednu vezu u privremenu listu i osvežava prikaz.
        private void AddVeza_Click(object sender, RoutedEventArgs e)
        {
            if (SporedniComboBox.SelectedItem is SporedniEntitet selektovani &&
                double.TryParse(KolicinaTextBox.Text, out double kol) &&
                !string.IsNullOrWhiteSpace(MernaJedinicaTextBox.Text))
            {
                var novaVeza = new Veza
                {
                    SporedniEntitetId = selektovani.Id,
                    SporedniEntitet = selektovani, // Važno za prikaz u ListView
                    Kolicina = kol,
                    MernaJedinica = MernaJedinicaTextBox.Text
                };
                _privremeneVeze.Add(novaVeza);

                // Trik za osvežavanje ListView-a
                VezeListView.ItemsSource = null;
                VezeListView.ItemsSource = _privremeneVeze;
            }
            else
            {
                MessageBox.Show("Molimo vas, popunite sva polja za vezu ispravno.");
            }
        }

        // Finalno čuvanje celog glavnog entiteta.
        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(NazivTextBox.Text)) { MessageBox.Show("Molimo unesite naziv."); return; }
            if (_privremeneVeze.Count == 0) { MessageBox.Show("Morate dodati barem jednu povezanu stavku."); return; }

            // Kreiramo novi objekat i dodeljujemo mu podatke iz forme
            var noviGlavni = new GlavniEntitet
            {
                Naziv = NazivTextBox.Text,
                Opis = OpisTextBox.Text,
                Veze = _privremeneVeze // Dodeljujemo mu listu veza koju smo skupljali
            };

            _glavniService.Add(noviGlavni); // Pozivamo servis da sačuva sve
            this.Close();
        }
    }
}