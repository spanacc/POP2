﻿using WpfCrudTemplate.Models;
using WpfCrudTemplate.Services;
using System.Windows;
namespace WpfCrudTemplate.Windows
{
    public partial class AddSporedniWindow : Window
    {
        private readonly SporedniEntitetService _service = new SporedniEntitetService();
        public AddSporedniWindow() { InitializeComponent(); }

        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(NazivTextBox.Text)) { MessageBox.Show("Molimo unesite naziv."); return; }
            _service.Add(new SporedniEntitet { Naziv = NazivTextBox.Text });
            this.Close(); // Zatvori prozor nakon čuvanja
        }
    }
}